This is a simple add-on for godot that adds an in-app notification system for 
displaying customizable pop-up notifications.

- Use:
	All you need to do is call the function "notify" from the NotificationEngine autoload with 
	a payload as the only accepted argument (More info about the payload next).

- Payload:
	The content and attributes of the notification are parametrized through a dictionary that 
	functions as a payload.
	
	This approach allows for a flexible and extensible system that consents the user to have 
	an incomplete payload in case of simpler notifications without compromising what the user 
	could do

- Payload format:
	the payload should be formatted like so (with one or more key-value elements missing in case
	you don't need every parameter):
	
	var payload : Dictionary = {
		"title" : "title string" 			# allows BBCode
		"body" : "body string" 				# allows BBCode
		"duration" : 6.9 					# (in seconds) how long should the popup stay
		"animation_duration" : 6.7 			# (in seconds) how fast should the popup and  popout animation last
	}
	# Future updates will include: 
		# - "icon": icon_resource (likely will be Texture2D)
		# - "actions" : [{"id_action_1" : "title_action_1}, {"id_2" : "title_2"}, ...]  (buttons for actions)
	
	Note:
		If one or more keys are wrong, contain typos or don't exist in this format these erroneous keys will be
		ignored.

- Example:
	...
	var payload : Dictionary = {
		"title":"🔳 QR code saved 🔳",
		"body":"QR code has been saved!",
		"duration":5.0,
		"animation_duration":0.3
	}
	NotificationEngine.notify(payload)
	...
